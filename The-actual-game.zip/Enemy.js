class Enemy {
  constructor() {
    this.x = 0;
    this.y = 0;
    this.width = 50;
    this.height = 50;

    this.speed = 5;
  }
}